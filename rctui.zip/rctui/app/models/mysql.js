var mysql  =  require('mysql');
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '123456',
    database : 'world'
});

connection.connect();
/*
connection.query('select * from city WHERE id = 1', function (error, results, fields) {
    if (error) throw error;
    console.log('The solution is: ', results);
});*/

module.exports =  function (res){
    connection.query('select * from city WHERE id < 10', function (error, results, fields) {
        if (error) throw error;
        console.log('The solution is: ', results);
        res.json(results)
    });
}