/**
 * Created by zdluoa on 2017/7/5.
 */
import React, {Component} from 'react';
import {Table} from 'rctui';

class Test extends Component{
    render(){
        return (
            <Table  fetch={{
                url : '/table',
                then : (res)=>{
                    console.log(res)
                    return res;
                }
            }} columns={[{
                    header : 'ID',
                    name : 'ID'
                },{
                header : 'Name',
                name : 'Name'
            }]}/>
        )
    }
}

export default Test;