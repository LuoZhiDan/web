/**
 * Created by zdluoa on 2017/7/5.
 */
import React, {Component} from 'react';
import {Button, Table} from 'rctui';

class Test extends Component{
    render(){
        return (
            <Button onClick={()=>{
                fetch('/device/update',
                    {   method:'POST',
                        headers : { "Content-Type": "application/json"},
                        body : JSON.stringify({name : 'luozhidan', age :10})})
                    .then((response)=>response.json())
                    .then((data)=>{
                        console.log(data)
                    });
            }}>登录</Button>
        )
    }
}

export default Test;